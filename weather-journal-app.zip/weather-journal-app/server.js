// Setup empty JS object to act as endpoint for all routes
projectData = {};

// Require Express to run server and routes
const express = require('express');
// Start up an instance of app
const app = express();

// Require bodyParser
const bodyParser = require('body-parser');

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Cors for cross origin allowance
const cors = require('cors');
app.use(cors());

// Initialize the main project folder
app.use(express.static('website'));


// Setup Server
// set your variables
const port = 1998 ; 
// Utilize the .listen()mathod
const server = app.listen( port , ()=> {console.log(`running on localhost: ${port}`)});
// use arrow function in the second argument instead of regular function to callback to debug
// Create a server with a callback function

// Respond with JS object when a GET request is made to the homepage
//  create a GET route that uses the url /all and returns the JavaScript object named projectData.
app.get('/all', function (request, response) {
    response.send(projectData);
  });


// create post() with a url path and a callback function
app.post('/add', add);
//In the callback function, add the data received from request.body
function add ( req , res){ 
  projectData = { ...req.body };
  res.send(projectData);
};