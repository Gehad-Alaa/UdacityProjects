# Weather-Journal App Project

// Web - Professional Track - Weather App - Project Walkthrough
https://udacity.zoom.us/rec/play/rcd9HBVbD7Es51VMYifxWUL4GwiUkJSzz6trKFgn4bNaWRTJRhMFy2qWfcgW8rs-5qLvMO2il-SETSeI.mJHiBx-I48k3n5qC?autoplay=true&startTime=1622917828000

// Setup Server
https://classroom.udacity.com/nanodegrees/nd001-mena-nfp2/parts/5c546e88-361e-4c4d-8fbd-1ad6dee27810/modules/42f360ec-ea7d-4619-8780-882642a3edd3/lessons/67f93c1e-ba0e-4049-80c8-9e548fccace0/concepts/1b9b1620-cb5b-4289-9caf-afd31d498d86

// Create API credentials on OpenWeatherMap.com
https://openweathermap.org/

//  create a GET route
https://classroom.udacity.com/nanodegrees/nd001-mena-nfp2/parts/5c546e88-361e-4c4d-8fbd-1ad6dee27810/modules/42f360ec-ea7d-4619-8780-882642a3edd3/lessons/710c6baf-41e9-4c9c-8ff3-d97763da566e/concepts/0fb536c7-a360-4cbc-b480-f4d4606b0fa3

// create post() with a url path and a callback function
https://classroom.udacity.com/nanodegrees/nd001-mena-nfp2/parts/5c546e88-361e-4c4d-8fbd-1ad6dee27810/modules/42f360ec-ea7d-4619-8780-882642a3edd3/lessons/710c6baf-41e9-4c9c-8ff3-d97763da566e/concepts/bfcd4972-22ff-47ff-9b2e-5453af288361

https://udacity.zoom.us/rec/play/rcd9HBVbD7Es51VMYifxWUL4GwiUkJSzz6trKFgn4bNaWRTJRhMFy2qWfcgW8rs-5qLvMO2il-SETSeI.mJHiBx-I48k3n5qC?autoplay=true&startTime=1622917828000
at moment 01:11:30

// Integrating OpenWeatherMap API
https://docs.google.com/presentation/d/1EVR9iePrSVLB1PVEU-nP8LJJDmc98x1QUKbK-2eI2A8/edit?ts=5fe4fdce#slide=id.gb2122f77f0_0_6

https://udacity.zoom.us/rec/play/rcd9HBVbD7Es51VMYifxWUL4GwiUkJSzz6trKFgn4bNaWRTJRhMFy2qWfcgW8rs-5qLvMO2il-SETSeI.mJHiBx-I48k3n5qC?autoplay=true&startTime=1622917828000
at moment 00:46:36

https://classroom.udacity.com/nanodegrees/nd001-mena-nfp2/parts/5c546e88-361e-4c4d-8fbd-1ad6dee27810/modules/42f360ec-ea7d-4619-8780-882642a3edd3/lessons/47a9fa8a-af7d-4701-81d4-3aa6966f07e0/concepts/464f740d-4c9a-4d45-9aab-7b72b43c1570

// Declare postData async function 
https://docs.google.com/presentation/d/1EVR9iePrSVLB1PVEU-nP8LJJDmc98x1QUKbK-2eI2A8/edit?ts=5fe4fdce#slide=id.gb2122f77f0_0_25

https://classroom.udacity.com/nanodegrees/nd001-mena-nfp2/parts/5c546e88-361e-4c4d-8fbd-1ad6dee27810/modules/42f360ec-ea7d-4619-8780-882642a3edd3/lessons/47a9fa8a-af7d-4701-81d4-3aa6966f07e0/concepts/286a4a78-20f9-4831-ba06-a40a70fd8128


## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
This will require modifying the `server.js` file and the `website/app.js` file. You can see `index.html` for element references, and once you are finished with the project steps, you can use `style.css` to style your application to customized perfection.

## Extras
If you are interested in testing your code as you go, you can use `tests.js` as a template for writing and running some basic tests for your code.
