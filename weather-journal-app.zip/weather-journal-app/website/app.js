/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1 +'.'+ d.getDate()+'.'+ d.getFullYear();

// Integrating OpenWeatherMap API
// Create API credentials on OpenWeatherMap.com and save it in a named const variable.
const apiKey = 'cf0bc2e481696e8cc0372d0314a56c54';
// baseUrl = `https://api.openweathermap.org/data/2.5/weather?zip=${zipcode}&appid=${APIkey}&units=imperial`

// get generate button from clien side interface
const generate = document.getElementById("generate");

generate.addEventListener( "click" , handleGenerateBtnClick);

async function handleGenerateBtnClick(x) {
    const data = await getWeatherInfo();
    postGet(data);
};

const getWeatherInfo = async()=>{
    // get zipcode from clien side interface
    const zipcode = document.getElementById("zip").value ;

    // If no value, alert the user to enter a zip code alert
    if(!zipcode){
        alert("Please, enter a zip code")
    };

    // get feelings from clien side interface
    const feelings = document.getElementById("feelings").value ;

    // If no value, alert the user to enter feelings
    if(!feelings){
        alert("Please, enter your feelings")
    };
    
    // The API Key variable is passed as a parameter to fetch() .
    const getInfo = await fetch(`https://api.openweathermap.org/data/2.5/weather?zip=${zipcode}&appid=cf0bc2e481696e8cc0372d0314a56c54&units=imperial`)
    //  call API 
    try {
        // let information readable for me 
        const data = await getInfo.json();
        const newEntry = {
            date: newDate,
            temp: data.main.temp,
            feelings: feelings
        }
        return newEntry
    }catch(error){
        console.log("Error",error);
    }

};

// Declare postData async function with a default parameters url
const postData = async ( url = '', data = {})=>{
    const sendToPost = await fetch( url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        date : data.date,
        temp : data.temp,
        feelings : data.feelings
    })     
  });
  try {
    const newData = await sendToPost.json();
           return newData
  }catch(error) {
  console.log("Error", error);
  }
}

// Async GET
const retrieveData = async (url='') =>{ 
    const request = await fetch(url);
    try {
    // Transform into JSON
    const allData = await request.json()
    
    // Write updated data to DOM elements
    document.getElementById('temp').innerHTML = Math.round(allData.temp)+ 'F°(fahrenheit degrees)';
    document.getElementById('content').innerHTML = allData.feelings;
    document.getElementById("date").innerHTML =allData.date;
    }
    catch(error) {
      console.log("error", error);
    }
  };

// Chain my async functions to post a weather then GET the resulting data
function postGet(data){
    postData('/add', data)
    .then(function(data){
    retrieveData('/all');
    })
}